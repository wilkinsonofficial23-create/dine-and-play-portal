/*
# Add status and score columns to leads table

## Changes
1. `leads` table gets two new columns:
   - `status` (text, default 'PENDING') — 'WON', 'LOSS', or 'PENDING' (for leads who haven't played an official round yet)
   - `score` (int, default 0) — the player's final score from their last game session
2. Backfills existing rows: status = 'WON' where has_won = true, else 'PENDING'

## Security
- No policy changes needed; existing RLS policies already cover the new columns.
*/

ALTER TABLE leads ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'PENDING';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score int NOT NULL DEFAULT 0;

UPDATE leads SET status = 'WON' WHERE has_won = true AND status = 'PENDING';
