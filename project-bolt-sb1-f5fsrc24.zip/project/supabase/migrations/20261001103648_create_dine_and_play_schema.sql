/*
# Dine & Play Portal — Multi-Tenant SaaS Schema

## Purpose
A restaurant gamification SaaS where each store (tenant) configures branding,
game rules, and collects customer leads via table QR codes. Customers scan a
QR code, register with OTP, play an arcade game, and win discount rewards
redeemable via WhatsApp.

## New Tables

1. `store_settings` — one row per tenant store
   - `tenant_id` (text, primary key) — the store identifier used in URLs (?tenant=store_id)
   - `business_name` (text) — display name on the hub
   - `sub_text` (text) — tagline under the name
   - `logo_url` (text) — optional logo image URL
   - `whatsapp_number` (text) — WhatsApp business number for reward redemption
   - `target_score` (int) — score needed to win the game
   - `offer_desc` (text) — reward/offer description shown on the result screen
   - `store_password` (text) — password for owner dashboard access
   - `created_at` (timestamptz)

2. `leads` — customer registrations per tenant
   - `id` (uuid, primary key)
   - `tenant_id` (text) — which store this lead belongs to
   - `lead_key` (text) — sanitized phone number, unique per tenant
   - `name` (text)
   - `phone` (text)
   - `email` (text)
   - `promo_consent` (text) — 'YES' or 'NO'
   - `table_id` (text) — which table the customer played from
   - `tries_used` (int, default -1) — -1 = practice, 0-2 = official tries
   - `last_played_time` (bigint) — timestamp of last play (ms epoch)
   - `has_won` (boolean, default false)
   - `win_code` (text, default '-')
   - `created_at` (timestamptz)

3. `analytics` — aggregate play/win counters per tenant
   - `tenant_id` (text, primary key)
   - `total_plays` (int, default 0)
   - `total_wins` (int, default 0)

## Security
- RLS enabled on all tables.
- This is a no-auth app (customers don't sign in; store owners use a simple
  password stored in store_settings). Policies use `TO anon, authenticated`
  so the anon-key frontend can read and write data.
- All data is scoped by tenant_id — customers can only interact with the
  tenant they accessed via the URL parameter.
*/

-- Store settings table
CREATE TABLE IF NOT EXISTS store_settings (
  tenant_id text PRIMARY KEY,
  business_name text NOT NULL DEFAULT 'Xpress Cafe & Lounge',
  sub_text text NOT NULL DEFAULT 'Scan table QR, play game & win discounts!',
  logo_url text DEFAULT '',
  whatsapp_number text NOT NULL DEFAULT '971501234567',
  target_score int NOT NULL DEFAULT 5,
  offer_desc text NOT NULL DEFAULT '15% off your total bill or a complimentary dessert!',
  store_password text NOT NULL DEFAULT 'store123',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE store_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_store_settings" ON store_settings;
CREATE POLICY "anon_read_store_settings" ON store_settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_update_store_settings" ON store_settings;
CREATE POLICY "anon_update_store_settings" ON store_settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_insert_store_settings" ON store_settings;
CREATE POLICY "anon_insert_store_settings" ON store_settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- Leads table
CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id text NOT NULL,
  lead_key text NOT NULL,
  name text NOT NULL,
  phone text NOT NULL,
  email text NOT NULL,
  promo_consent text NOT NULL DEFAULT 'YES',
  table_id text NOT NULL DEFAULT 'Table-1',
  tries_used int NOT NULL DEFAULT -1,
  last_played_time bigint NOT NULL DEFAULT 0,
  has_won boolean NOT NULL DEFAULT false,
  win_code text NOT NULL DEFAULT '-',
  created_at timestamptz DEFAULT now(),
  UNIQUE(tenant_id, lead_key)
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_leads" ON leads;
CREATE POLICY "anon_select_leads" ON leads FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads" ON leads FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_leads" ON leads;
CREATE POLICY "anon_update_leads" ON leads FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_leads" ON leads;
CREATE POLICY "anon_delete_leads" ON leads FOR DELETE
  TO anon, authenticated USING (true);

-- Analytics table
CREATE TABLE IF NOT EXISTS analytics (
  tenant_id text PRIMARY KEY,
  total_plays int NOT NULL DEFAULT 0,
  total_wins int NOT NULL DEFAULT 0
);

ALTER TABLE analytics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_analytics" ON analytics;
CREATE POLICY "anon_select_analytics" ON analytics FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_analytics" ON analytics;
CREATE POLICY "anon_insert_analytics" ON analytics FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_analytics" ON analytics;
CREATE POLICY "anon_update_analytics" ON analytics FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- Seed default store
INSERT INTO store_settings (tenant_id) VALUES ('default_store')
  ON CONFLICT (tenant_id) DO NOTHING;

INSERT INTO analytics (tenant_id) VALUES ('default_store')
  ON CONFLICT (tenant_id) DO NOTHING;

-- Indexes for efficient tenant-scoped queries
CREATE INDEX IF NOT EXISTS idx_leads_tenant ON leads(tenant_id);
CREATE INDEX IF NOT EXISTS idx_leads_tenant_key ON leads(tenant_id, lead_key);
