import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { StoreSettings, Lead, Analytics } from '@/lib/types';
import { DEFAULT_STORE_SETTINGS } from '@/lib/types';

interface TenantData {
  settings: StoreSettings;
  leads: Record<string, Lead>;
  analytics: Analytics;
  loading: boolean;
}

export function useTenant(tenantId: string): TenantData & { refetchAnalytics: () => Promise<void> } {
  const [settings, setSettings] = useState<StoreSettings>({
    ...DEFAULT_STORE_SETTINGS,
    tenant_id: tenantId,
  });
  const [leads, setLeads] = useState<Record<string, Lead>>({});
  const [analytics, setAnalytics] = useState<Analytics>({
    tenant_id: tenantId,
    total_plays: 0,
    total_wins: 0,
  });
  const [loading, setLoading] = useState(true);

  const refetchAnalytics = useCallback(async () => {
    const { data } = await supabase
      .from('analytics')
      .select('*')
      .eq('tenant_id', tenantId)
      .maybeSingle();
    if (data) setAnalytics(data as Analytics);
  }, [tenantId]);

  useEffect(() => {
    let mounted = true;

    // Load settings
    const loadSettings = async () => {
      const { data } = await supabase
        .from('store_settings')
        .select('*')
        .eq('tenant_id', tenantId)
        .maybeSingle();
      if (mounted && data) setSettings(data as StoreSettings);
      else if (mounted) {
        // Create default settings for new tenant
        const newSettings = { ...DEFAULT_STORE_SETTINGS, tenant_id: tenantId };
        await supabase.from('store_settings').upsert(newSettings);
        setSettings(newSettings);
      }
    };

    const loadLeads = async () => {
      const { data } = await supabase
        .from('leads')
        .select('*')
        .eq('tenant_id', tenantId);
      if (mounted && data) {
        const map: Record<string, Lead> = {};
        (data as Lead[]).forEach((l) => { map[l.lead_key] = l; });
        setLeads(map);
      }
    };

    const loadAnalytics = async () => {
      const { data } = await supabase
        .from('analytics')
        .select('*')
        .eq('tenant_id', tenantId)
        .maybeSingle();
      if (mounted && data) setAnalytics(data as Analytics);
      else if (mounted) {
        const newAnalytics = { tenant_id: tenantId, total_plays: 0, total_wins: 0 };
        await supabase.from('analytics').upsert(newAnalytics);
        setAnalytics(newAnalytics);
      }
    };

    Promise.all([loadSettings(), loadLeads(), loadAnalytics()]).then(() => {
      if (mounted) setLoading(false);
    });

    // Realtime subscriptions
    const settingsChannel = supabase
      .channel(`settings-${tenantId}`)
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'store_settings', filter: `tenant_id=eq.${tenantId}` },
        (payload) => {
          if (payload.new) setSettings(payload.new as StoreSettings);
        }
      )
      .subscribe();

    const leadsChannel = supabase
      .channel(`leads-${tenantId}`)
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'leads', filter: `tenant_id=eq.${tenantId}` },
        (payload) => {
          if (payload.eventType === 'UPDATE' && payload.new) {
            const updatedLead = payload.new as Lead;
            setLeads((prev) => ({
              ...prev,
              [updatedLead.lead_key]: updatedLead,
            }));
          } else if (payload.eventType === 'INSERT' && payload.new) {
            const newLead = payload.new as Lead;
            setLeads((prev) => ({
              ...prev,
              [newLead.lead_key]: newLead,
            }));
          } else if (payload.eventType === 'DELETE' && payload.old) {
            const oldLead = payload.old as Lead;
            setLeads((prev) => {
              const next = { ...prev };
              delete next[oldLead.lead_key];
              return next;
            });
          } else {
            loadLeads();
          }
        }
      )
      .subscribe();

    const analyticsChannel = supabase
      .channel(`analytics-${tenantId}`)
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'analytics', filter: `tenant_id=eq.${tenantId}` },
        (payload) => {
          if (payload.new) setAnalytics(payload.new as Analytics);
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(settingsChannel);
      supabase.removeChannel(leadsChannel);
      supabase.removeChannel(analyticsChannel);
    };
  }, [tenantId]);

  return { settings, leads, analytics, loading, refetchAnalytics };
}
