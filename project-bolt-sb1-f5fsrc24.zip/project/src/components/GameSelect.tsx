import { useState } from 'react';
import type { GameType } from '@/lib/types';

interface GameSelectProps {
  onConfirm: (game: GameType) => void;
  onBack: () => void;
}

const GAMES: { id: GameType; icon: string; title: string; desc: string }[] = [
  { id: 'snake', icon: '🐍', title: 'Snake Game', desc: 'Classic arcade fun. Eat food & score points!' },
  { id: 'flappy', icon: '🐦', title: 'Flappy Bird', desc: 'Tap to jump & navigate through the pipes!' },
  { id: 'eggtoss', icon: '🥚', title: 'Egg Toss', desc: 'Tap to toss the egg into moving baskets upward!' },
];

export default function GameSelect({ onConfirm, onBack }: GameSelectProps) {
  const [selected, setSelected] = useState<GameType>('snake');

  return (
    <div className="flex flex-col flex-1 px-5 py-4 overflow-y-auto">
      <h3 className="text-center text-red-400 text-[22px] font-bold mt-0">Choose Your Game</h3>
      <p className="text-center text-xs text-slate-500 mb-3">Select a game challenge to unlock discount rewards!</p>

      <div className="flex flex-col gap-4 my-5">
        {GAMES.map((g) => (
          <button
            key={g.id}
            onClick={() => setSelected(g.id)}
            className={`bg-white border-2 rounded-2xl p-5 flex items-center gap-4 transition-all text-left ${
              selected === g.id
                ? 'border-red-400 bg-red-50 shadow-md'
                : 'border-slate-200 hover:border-red-400 hover:translate-y-[-2px]'
            }`}
          >
            <div className="text-4xl w-[60px] h-[60px] bg-slate-50 rounded-2xl flex items-center justify-center border border-slate-200">
              {g.icon}
            </div>
            <div>
              <div className="font-extrabold text-base text-slate-800">{g.title}</div>
              <div className="text-xs text-slate-500 mt-0.5">{g.desc}</div>
            </div>
          </button>
        ))}
      </div>

      <button
        onClick={() => onConfirm(selected)}
        className="w-full py-3.5 rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-bold text-[15px] shadow-lg shadow-red-400/30 hover:translate-y-[-1px] transition-transform"
      >
        Play Game 🚀
      </button>
      <button onClick={onBack} className="text-center mt-3.5 text-xs text-slate-500 font-semibold hover:text-slate-800 hover:underline">
        ⬅️ Back to Hub
      </button>
    </div>
  );
}
