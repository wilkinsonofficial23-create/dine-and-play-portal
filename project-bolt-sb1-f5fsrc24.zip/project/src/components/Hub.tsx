import { Settings } from 'lucide-react';
import type { StoreSettings } from '@/lib/types';

interface HubProps {
  settings: StoreSettings;
  onPlayClick: () => void;
  onAdminClick: () => void;
}

export default function Hub({ settings, onPlayClick, onAdminClick }: HubProps) {
  return (
    <div className="flex flex-col flex-1">
      <div className="h-32 bg-gradient-to-br from-slate-800 to-slate-700 relative flex justify-end p-4">
        <button
          onClick={onAdminClick}
          className="bg-red-400 text-white px-4 py-2 rounded-full text-xs font-bold flex items-center gap-1.5 h-fit shadow-md hover:translate-y-[-1px] transition-transform"
        >
          <Settings size={14} />
          Admin
        </button>
      </div>

      <div className="px-5 pt-6 pb-5 flex flex-col items-center text-center">
        <div className="rounded-full border-4 border-white bg-slate-300 overflow-hidden shadow-lg flex items-center justify-center text-3xl -mt-16" style={{ width: 80, height: 80 }}>
          {settings.logo_url ? (
            <img src={settings.logo_url} alt="Logo" className="w-full h-full object-cover" />
          ) : (
            '☕'
          )}
        </div>
        <div className="text-xl font-extrabold text-slate-800 mt-3">{settings.business_name}</div>
        <div className="text-[13px] text-slate-500 mt-1">{settings.sub_text}</div>
      </div>

      <div className="px-5 pb-8 flex flex-col gap-3.5 flex-1">
        <button
          onClick={onPlayClick}
          className="bg-white border border-slate-200 rounded-2xl px-5 py-4 flex items-center justify-between shadow-sm hover:border-red-400 hover:translate-y-[-2px] hover:shadow-md transition-all text-left"
        >
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-red-100 text-red-500 flex items-center justify-center text-xl">🎮</div>
            <div>
              <div className="text-[15px] font-bold text-slate-800">Play and Win</div>
              <div className="text-xs text-slate-500 mt-0.5">Play table challenge & unlock rewards</div>
            </div>
          </div>
          <span className="text-slate-400 text-base font-bold">›</span>
        </button>

        <div className="bg-white border border-slate-200 rounded-2xl px-5 py-4 flex items-center justify-between shadow-sm text-left">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center text-xl">📖</div>
            <div>
              <div className="text-[15px] font-bold text-slate-800">View Menu</div>
              <div className="text-xs text-slate-500 mt-0.5">Explore our food & beverage items</div>
            </div>
          </div>
          <span className="text-slate-400 text-base font-bold">›</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl px-5 py-4 flex items-center justify-between shadow-sm text-left">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-green-100 text-green-600 flex items-center justify-center text-xl">📶</div>
            <div>
              <div className="text-[15px] font-bold text-slate-800">Connect to Wi-Fi</div>
              <div className="text-xs text-slate-500 mt-0.5">Get instant high-speed network access</div>
            </div>
          </div>
          <span className="text-slate-400 text-base font-bold">›</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl px-5 py-4 flex items-center justify-between shadow-sm text-left">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-violet-100 text-violet-600 flex items-center justify-center text-xl">💬</div>
            <div>
              <div className="text-[15px] font-bold text-slate-800">Leave Anonymous Feedback</div>
              <div className="text-xs text-slate-500 mt-0.5">Help us improve your experience</div>
            </div>
          </div>
          <span className="text-slate-400 text-base font-bold">›</span>
        </div>

        <a
          href="https://google.com"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-white border border-slate-200 rounded-2xl px-5 py-4 flex items-center justify-between shadow-sm hover:border-red-400 hover:translate-y-[-2px] hover:shadow-md transition-all text-left"
        >
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center text-xl">⭐</div>
            <div>
              <div className="text-[15px] font-bold text-slate-800">Leave a Google Review</div>
              <div className="text-xs text-slate-500 mt-0.5">Share your feedback on Google Maps</div>
            </div>
          </div>
          <span className="text-slate-400 text-base font-bold">›</span>
        </a>
      </div>
    </div>
  );
}
