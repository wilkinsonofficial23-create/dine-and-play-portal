import { useState, useEffect } from 'react';
import { BarChart3, Download, LogOut, Save, TrendingUp } from 'lucide-react';
import type { StoreSettings, Lead, Analytics } from '@/lib/types';
import { supabase } from '@/lib/supabase';

interface OwnerDashboardProps {
  tenantId: string;
  settings: StoreSettings;
  leads: Record<string, Lead>;
  analytics: Analytics;
  onBack: () => void;
  onLogout: () => void;
}

export default function OwnerDashboard({ tenantId, settings, leads, analytics, onBack, onLogout }: OwnerDashboardProps) {
  const [busName, setBusName] = useState(settings.business_name);
  const [subText, setSubText] = useState(settings.sub_text);
  const [logoUrl, setLogoUrl] = useState(settings.logo_url);
  const [whatsappNumber, setWhatsappNumber] = useState(settings.whatsapp_number);
  const [targetScore, setTargetScore] = useState(settings.target_score);
  const [offerDesc, setOfferDesc] = useState(settings.offer_desc);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [saveMsg, setSaveMsg] = useState('');

  useEffect(() => {
    setBusName(settings.business_name);
    setSubText(settings.sub_text);
    setLogoUrl(settings.logo_url);
    setWhatsappNumber(settings.whatsapp_number);
    setTargetScore(settings.target_score);
    setOfferDesc(settings.offer_desc);
  }, [settings]);

  const leadArray = Object.values(leads);
  const totalLeads = leadArray.length;
  const totalPlays = analytics.total_plays;
  const totalWins = analytics.total_wins;
  const winRate = totalPlays > 0 ? Math.round((totalWins / totalPlays) * 100) : 0;

  const handleSave = async () => {
    const updated = {
      business_name: busName.trim(),
      sub_text: subText.trim(),
      logo_url: logoUrl.trim(),
      whatsapp_number: whatsappNumber.trim(),
      target_score: parseInt(String(targetScore)) || 5,
      offer_desc: offerDesc.trim(),
    };
    const { error } = await supabase
      .from('store_settings')
      .update(updated)
      .eq('tenant_id', tenantId);
    if (error) {
      setSaveMsg('Failed to save settings. Please try again.');
      setTimeout(() => setSaveMsg(''), 3000);
      return;
    }
    setSaveMsg('Settings saved & pushed live! Customer screens will update instantly.');
    setTimeout(() => setSaveMsg(''), 3000);
  };

  const exportCSV = (promoOnly: boolean) => {
    const data = promoOnly ? leadArray.filter((l) => (l.promo_consent || 'YES') === 'YES') : leadArray;
    if (!data.length) {
      alert(promoOnly ? 'No promotional opt-in leads found to export!' : 'No leads to export!');
      return;
    }

    let csv = 'Name,Phone,Email,Promo Consent,Table,Status,Win Code,Score,Tries Used\n';
    data.forEach((l) => {
      const code = l.win_code && l.win_code !== '-' && l.win_code !== '' ? l.win_code : '-';
      const status = l.status || (l.has_won ? 'WON' : 'PENDING');
      csv += `"${l.name}","${l.phone}","${l.email}","${l.promo_consent || 'YES'}","${l.table_id || 'Table-1'}","${status}","${code}","${l.score ?? 0}","${l.tries_used}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${promoOnly ? 'Promo_OptIns' : 'Leads'}_${tenantId}.csv`;
    a.click();
  };

  const getStatusBadge = (lead: Lead) => {
    const status = lead.status || (lead.has_won ? 'WON' : 'PENDING');
    if (status === 'WON') {
      return <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase text-white bg-green-500">WIN</span>;
    }
    if (status === 'LOSS') {
      return <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase text-white bg-red-500">LOSS</span>;
    }
    return <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase text-white bg-slate-400">PENDING</span>;
  };

  return (
    <div className="fixed inset-0 bg-slate-50 z-[200] flex flex-col overflow-y-auto">
      <div className="bg-white px-6 py-5 border-b border-slate-200 flex justify-between items-center shadow-sm">
        <div>
          <h2 className="text-2xl text-red-400 font-bold m-0">{settings.business_name} Portal</h2>
          <span className="text-[13px] text-slate-500">Changes sync instantly to table QR links worldwide</span>
        </div>
        <div className="flex gap-3">
          <button onClick={onBack} className="px-5 py-2.5 rounded-xl bg-gradient-to-br from-slate-300 to-slate-400 text-slate-700 font-bold text-sm">
            📱 Back to Hub
          </button>
          <button onClick={onLogout} className="px-5 py-2.5 rounded-xl bg-gradient-to-br from-slate-300 to-slate-400 text-slate-700 font-bold text-sm flex items-center gap-1.5">
            <LogOut size={16} />
            Logout
          </button>
        </div>
      </div>

      <div className="p-6 md:p-8 flex-1 overflow-y-auto">
        <div className="md:grid md:grid-cols-12 md:gap-6 max-w-[1400px] mx-auto">
          {/* Left: Settings */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 mb-6 md:mb-0 md:col-span-5">
            <h3 className="text-lg text-sky-600 flex items-center gap-2.5 mb-5 font-bold">🛠 Store Branding & Game Rules</h3>

            <div className="mb-4">
              <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">Restaurant / Store Name</label>
              <input type="text" value={busName} onChange={(e) => setBusName(e.target.value)} className="w-full px-3.5 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-slate-800 focus:border-red-400 focus:bg-white focus:outline-none transition" />
            </div>
            <div className="mb-4">
              <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">Sub-Header Tagline</label>
              <input type="text" value={subText} onChange={(e) => setSubText(e.target.value)} className="w-full px-3.5 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-slate-800 focus:border-red-400 focus:bg-white focus:outline-none transition" />
            </div>
            <div className="mb-4">
              <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">Logo Image URL</label>
              <input type="text" value={logoUrl} onChange={(e) => setLogoUrl(e.target.value)} placeholder="https://..." className="w-full px-3.5 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-slate-800 focus:border-red-400 focus:bg-white focus:outline-none transition" />
            </div>
            <div className="mb-4">
              <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">WhatsApp Business Number (with country code)</label>
              <input type="text" value={whatsappNumber} onChange={(e) => setWhatsappNumber(e.target.value)} placeholder="971501234567" className="w-full px-3.5 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-slate-800 focus:border-red-400 focus:bg-white focus:outline-none transition" />
            </div>
            <div className="mb-4">
              <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">Target Score to Win</label>
              <input type="number" min={1} max={30} value={targetScore} onChange={(e) => setTargetScore(Number(e.target.value))} className="w-full px-3.5 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-slate-800 focus:border-red-400 focus:bg-white focus:outline-none transition" />
            </div>
            <div className="mb-4">
              <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">Reward / Offer Description</label>
              <textarea value={offerDesc} onChange={(e) => setOfferDesc(e.target.value)} rows={3} className="w-full px-3.5 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-slate-800 focus:border-red-400 focus:bg-white focus:outline-none transition resize-none" />
            </div>

            {saveMsg && <p className="text-green-600 text-sm mb-2 font-semibold">{saveMsg}</p>}
            <button onClick={handleSave} className="w-full py-3.5 rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-bold text-[15px] shadow-lg shadow-red-400/30 hover:translate-y-[-1px] transition-transform flex items-center justify-center gap-2">
              <Save size={18} />
              Save & Push Live
            </button>
          </div>

          {/* Right: Analytics + Leads */}
          <div className="md:col-span-7">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 mb-6">
              <h3 className="text-lg text-sky-600 flex items-center gap-2.5 mb-5 font-bold">
                <BarChart3 size={20} />
                Performance Analytics
              </h3>
              <div className="grid grid-cols-2 gap-4 mb-5">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
                  <div className="text-[13px] text-slate-500 font-medium">Total Leads</div>
                  <div className="text-2xl font-extrabold text-red-400 mt-1.5">{totalLeads}</div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
                  <div className="text-[13px] text-slate-500 font-medium">Total Game Plays</div>
                  <div className="text-2xl font-extrabold text-red-400 mt-1.5">{totalPlays}</div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
                  <div className="text-[13px] text-slate-500 font-medium">Rewards Won</div>
                  <div className="text-2xl font-extrabold text-red-400 mt-1.5">{totalWins}</div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
                  <div className="text-[13px] text-slate-500 font-medium">Win Conversion</div>
                  <div className="text-2xl font-extrabold text-red-400 mt-1.5">{winRate}%</div>
                </div>
              </div>
              <button onClick={() => setShowAnalyticsModal(true)} className="w-full py-3 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-400 text-white font-bold text-sm shadow-lg shadow-violet-500/30 flex items-center justify-center gap-2">
                <TrendingUp size={18} />
                View Detailed Analytics Popup
              </button>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-6">
              <h3 className="text-lg text-sky-600 flex items-center gap-2.5 mb-5 font-bold">📋 Customer Leads Collected</h3>
              <div className="max-h-[280px] overflow-y-auto">
                <table className="w-full text-[13px] border-collapse">
                  <thead>
                    <tr>
                      <th className="border border-slate-200 px-3.5 py-3 text-left bg-slate-50 text-red-400 font-semibold">Name</th>
                      <th className="border border-slate-200 px-3.5 py-3 text-left bg-slate-50 text-red-400 font-semibold">Contact</th>
                      <th className="border border-slate-200 px-3.5 py-3 text-left bg-slate-50 text-red-400 font-semibold">Status</th>
                      <th className="border border-slate-200 px-3.5 py-3 text-left bg-slate-50 text-red-400 font-semibold">Win Code</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leadArray.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="border border-slate-200 px-3.5 py-6 text-center text-slate-400">No leads yet</td>
                      </tr>
                    ) : (
                      leadArray.map((lead) => {
                        const hasCode = lead.win_code && lead.win_code !== '-' && lead.win_code !== '';
                        return (
                          <tr key={lead.id}>
                            <td className="border border-slate-200 px-3.5 py-3 text-slate-800">{lead.name}</td>
                            <td className="border border-slate-200 px-3.5 py-3 text-slate-800">
                              {lead.phone}
                              <br />
                              <small className="text-slate-500">{lead.email}</small>
                            </td>
                            <td className="border border-slate-200 px-3.5 py-3">
                              {getStatusBadge(lead)}
                            </td>
                            <td className="border border-slate-200 px-3.5 py-3">
                              {hasCode ? (
                                <span className="inline-block px-2.5 py-1 rounded-md text-xs font-bold text-amber-800 bg-amber-100 border border-amber-300">
                                  {lead.win_code}
                                </span>
                              ) : (
                                <span className="text-slate-400">—</span>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
              <div className="flex gap-2.5 flex-wrap mt-4">
                <button onClick={() => exportCSV(false)} className="px-4 py-2.5 rounded-xl bg-gradient-to-br from-slate-300 to-slate-400 text-slate-700 font-bold text-[13px] flex items-center gap-1.5">
                  <Download size={16} />
                  Export Leads CSV
                </button>
                <button onClick={() => exportCSV(true)} className="px-4 py-2.5 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 text-white font-bold text-[13px] flex items-center gap-1.5">
                  <Download size={16} />
                  Export Opt-In Leads CSV
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showAnalyticsModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex justify-center items-center z-[500] p-5">
          <div className="bg-white border border-slate-200 rounded-3xl p-8 w-full max-w-lg shadow-2xl">
            <h3 className="text-red-400 text-xl font-bold mt-0">📊 Detailed Engagement Analytics</h3>
            <p className="text-[13px] text-slate-500">Comprehensive performance overview for your store location.</p>
            <div className="my-5 text-sm leading-relaxed">
              <div>👥 <strong>Total Customer Registrations:</strong> <span className="text-sky-600 font-bold">{totalLeads}</span></div>
              <div>🎮 <strong>Total Challenge Tries:</strong> <span className="text-sky-600 font-bold">{totalPlays}</span></div>
              <div>🏆 <strong>Total Rewards Claimed:</strong> <span className="text-sky-600 font-bold">{totalWins}</span></div>
              <div>🎯 <strong>Overall Win Conversion Rate:</strong> <span className="text-red-400 font-bold">{winRate}%</span></div>
              <div>⚡ <strong>Active Table Reach:</strong> <span className="text-slate-800">All tables synced via live cloud nodes</span></div>
            </div>
            <button onClick={() => setShowAnalyticsModal(false)} className="w-full py-3.5 rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-bold text-[15px] shadow-lg shadow-red-400/30">
              Close Popup
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
