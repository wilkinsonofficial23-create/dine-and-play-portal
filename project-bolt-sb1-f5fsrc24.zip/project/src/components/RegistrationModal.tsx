import { useState } from 'react';
import { COUNTRY_CODES, sanitizePhoneKey, validatePhone, validateEmail } from '@/lib/types';
import type { CustomerData } from '@/lib/types';
import { supabase } from '@/lib/supabase';
import { initAudio } from '@/lib/audio';

interface RegistrationModalProps {
  tenantId: string;
  tableId: string;
  onVerified: (data: CustomerData) => void;
  onBack: () => void;
}

export default function RegistrationModal({ tenantId, tableId, onVerified, onBack }: RegistrationModalProps) {
  const [name, setName] = useState('');
  const [countryCode, setCountryCode] = useState('+971');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [promoConsent, setPromoConsent] = useState(true);
  const [otpSent, setOtpSent] = useState(false);
  const [enteredOTP, setEnteredOTP] = useState('');
  const [generatedOTP, setGeneratedOTP] = useState('');
  const [error, setError] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [emailError, setEmailError] = useState('');

  const handlePhoneChange = (val: string) => {
    setPhone(val);
    if (phoneError) setPhoneError('');
  };

  const handleEmailChange = (val: string) => {
    setEmail(val);
    if (emailError) setEmailError('');
  };

  const handleSendOTP = (e: React.FormEvent) => {
    e.preventDefault();

    const phoneErr = validatePhone(phone);
    const emailErr = validateEmail(email);
    if (phoneErr) setPhoneError(phoneErr);
    if (emailErr) setEmailError(emailErr);
    if (phoneErr || emailErr) return;

    initAudio();
    const fullPhone = countryCode + phone.trim();
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOTP(otp);
    setOtpSent(true);
    setError('');
    alert(`Your Demo Verification OTP is: ${otp}`);
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    initAudio();
    if (enteredOTP.trim() !== generatedOTP) {
      setError('Invalid OTP. Please try again.');
      return;
    }

    const fullPhone = countryCode + phone.trim();
    const leadKey = sanitizePhoneKey(fullPhone);
    const customerData: CustomerData = {
      name: name.trim(),
      phone: fullPhone,
      email: email.trim(),
      promo_consent: promoConsent ? 'YES' : 'NO',
      tries_used: -1,
      last_played_time: 0,
      has_won: false,
      win_code: '',
      status: 'PENDING',
      score: 0,
    };

    const { data: existing } = await supabase
      .from('leads')
      .select('*')
      .eq('tenant_id', tenantId)
      .eq('lead_key', leadKey)
      .maybeSingle();

    if (!existing) {
      await supabase.from('leads').insert({
        tenant_id: tenantId,
        lead_key: leadKey,
        name: customerData.name,
        phone: customerData.phone,
        email: customerData.email,
        promo_consent: customerData.promo_consent,
        table_id: tableId,
        tries_used: -1,
        last_played_time: 0,
        has_won: false,
        win_code: '',
        status: 'PENDING',
        score: 0,
      });
    } else {
      await supabase
        .from('leads')
        .update({ promo_consent: customerData.promo_consent })
        .eq('tenant_id', tenantId)
        .eq('lead_key', leadKey);
    }

    onVerified(customerData);
  };

  return (
    <div className="flex flex-col flex-1 px-5 py-4 overflow-y-auto">
      <h3 className="text-center text-red-400 font-bold mt-0">Table Verification</h3>
      <p className="text-center text-xs text-slate-500 mb-3">Enter your details to start playing from your table!</p>

      {!otpSent ? (
        <form onSubmit={handleSendOTP}>
          <div className="mb-4">
            <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
              required
              className="w-full px-3.5 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-slate-800 text-base focus:border-red-400 focus:bg-white focus:outline-none transition"
            />
          </div>
          <div className="mb-4">
            <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">Phone Number</label>
            <div className="flex gap-2">
              <select
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                required
                className="flex-[0_0_120px] px-3 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-slate-800 text-base focus:border-red-400 focus:bg-white focus:outline-none transition"
              >
                {COUNTRY_CODES.map((c) => (
                  <option key={c.code} value={c.code}>{c.flag} {c.code}</option>
                ))}
              </select>
              <input
                type="tel"
                value={phone}
                onChange={(e) => handlePhoneChange(e.target.value)}
                placeholder="501234567"
                autoComplete="tel-national"
                inputMode="tel"
                required
                className={`flex-1 px-3.5 py-3 rounded-xl border-2 bg-slate-50 text-slate-800 text-base focus:bg-white focus:outline-none transition ${
                  phoneError ? 'border-red-400 focus:border-red-400' : 'border-slate-200 focus:border-red-400'
                }`}
              />
            </div>
            {phoneError && <p className="text-red-500 text-xs mt-1">{phoneError}</p>}
          </div>
          <div className="mb-4">
            <label className="block mb-1.5 text-[13px] font-semibold text-slate-500">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => handleEmailChange(e.target.value)}
              autoComplete="email"
              inputMode="email"
              required
              placeholder="name@example.com"
              className={`w-full px-3.5 py-3 rounded-xl border-2 bg-slate-50 text-slate-800 text-base focus:bg-white focus:outline-none transition ${
                emailError ? 'border-red-400 focus:border-red-400' : 'border-slate-200 focus:border-red-400'
              }`}
            />
            {emailError && <p className="text-red-500 text-xs mt-1">{emailError}</p>}
          </div>

          {/* Promotional consent Yes/No selection */}
          <div className="mt-2.5 mb-5">
            <label className="block mb-2 text-[13px] font-semibold text-slate-500">
              Would you like to receive promotional offers & updates via WhatsApp/SMS?
            </label>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setPromoConsent(true)}
                className={`flex-1 py-3 rounded-xl border-2 font-bold text-sm transition ${
                  promoConsent
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                    : 'border-slate-200 bg-slate-50 text-slate-500'
                }`}
              >
                Yes, I'd like offers
              </button>
              <button
                type="button"
                onClick={() => setPromoConsent(false)}
                className={`flex-1 py-3 rounded-xl border-2 font-bold text-sm transition ${
                  !promoConsent
                    ? 'border-slate-400 bg-slate-100 text-slate-700'
                    : 'border-slate-200 bg-slate-50 text-slate-500'
                }`}
              >
                No, thanks
              </button>
            </div>
          </div>

          <button type="submit" className="w-full py-3.5 rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-bold text-[15px] shadow-lg shadow-red-400/30 hover:translate-y-[-1px] transition-transform">
            Send Verification OTP
          </button>
        </form>
      ) : (
        <form onSubmit={handleVerifyOTP} className="mt-4">
          {error && <p className="text-red-500 text-sm text-center mb-2">{error}</p>}
          <div className="mb-4">
            <label className="block text-sky-600 font-bold text-center text-[13px] mb-1.5">Enter 6-Digit OTP</label>
            <input
              type="text"
              value={enteredOTP}
              onChange={(e) => setEnteredOTP(e.target.value)}
              maxLength={6}
              inputMode="numeric"
              autoComplete="one-time-code"
              required
              className="w-full px-3.5 py-3 rounded-xl border-2 border-slate-200 bg-slate-50 text-center text-[22px] tracking-[6px] font-bold focus:border-red-400 focus:bg-white focus:outline-none transition"
            />
          </div>
          <button type="submit" className="w-full py-3.5 rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-bold text-[15px] shadow-lg shadow-red-400/30 hover:translate-y-[-1px] transition-transform">
            Verify & Launch Game
          </button>
        </form>
      )}

      <button onClick={onBack} className="text-center mt-3 text-xs text-slate-500 font-semibold hover:text-slate-800 hover:underline">
        ⬅️ Change Selected Game
      </button>
    </div>
  );
}
