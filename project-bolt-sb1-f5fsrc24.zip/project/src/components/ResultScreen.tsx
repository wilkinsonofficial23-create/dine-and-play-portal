import type { CustomerData, StoreSettings } from '@/lib/types';
import { MAX_OFFICIAL_TRIES } from '@/lib/types';

interface ResultScreenProps {
  won: boolean;
  score: number;
  customerData: CustomerData;
  settings: StoreSettings;
  onNextRound: () => void;
  onBackToHub: () => void;
}

export default function ResultScreen({ won, score, customerData, settings, onNextRound, onBackToHub }: ResultScreenProps) {
  const isPractice = customerData.tries_used < 0;
  const outOfTries = customerData.tries_used >= MAX_OFFICIAL_TRIES;
  const showNextRound = !customerData.has_won && !outOfTries;

  let title: string;
  let message: string;

  if (won) {
    title = '🎉 Congratulations!';
    message = `You reached the target score of ${settings.target_score}!\n\n🎁 Reward: ${settings.offer_desc}\n🏷 Coupon Code: ${customerData.win_code}`;
  } else if (isPractice) {
    title = 'Practice Complete!';
    message = 'You finished your warm-up round. Ready for your official tries?';
  } else if (!outOfTries) {
    title = 'Try Failed';
    message = `You scored ${score}/${settings.target_score}. You have ${MAX_OFFICIAL_TRIES - customerData.tries_used} official tries remaining today.`;
  } else {
    title = 'Out of Tries';
    message = "You've used all 3 official tries for today. Come back in 24 hours to play again!";
  }

  const whatsappURL = won
    ? `https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(
        `Hi! I just won the game at ${settings.business_name}! 🎮 My winning coupon code is *${customerData.win_code}*. I'd like to redeem my reward!`
      )}`
    : '#';

  const nextRoundLabel = customerData.tries_used < 0
    ? 'Start Official Try 1'
    : `Start Official Try ${customerData.tries_used + 1}`;

  return (
    <div className="flex flex-col flex-1 px-5 py-4 overflow-y-auto items-center text-center justify-center">
      <h3 className="text-xl font-bold mb-2 text-slate-800">{title}</h3>
      <p className="text-[13px] text-slate-500 mb-4 leading-relaxed whitespace-pre-line">{message}</p>

      {won && (
        <div className="mb-4 w-full">
          <a
            href={whatsappURL}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 rounded-xl bg-gradient-to-br from-green-500 to-teal-600 text-white font-bold text-[15px] shadow-lg shadow-green-500/30 flex items-center justify-center gap-2 hover:translate-y-[-1px] transition-transform"
          >
            💬 Send Code on WhatsApp to Redeem
          </a>
        </div>
      )}

      {showNextRound && (
        <button
          onClick={onNextRound}
          className="w-full py-3.5 rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-bold text-[15px] shadow-lg shadow-red-400/30 hover:translate-y-[-1px] transition-transform"
        >
          {nextRoundLabel}
        </button>
      )}

      <button
        onClick={onBackToHub}
        className="w-full py-3.5 rounded-xl bg-gradient-to-br from-slate-300 to-slate-400 text-slate-700 font-bold text-[15px] mt-2.5"
      >
        🏠 Back to Hub
      </button>
    </div>
  );
}
