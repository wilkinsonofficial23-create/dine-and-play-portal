import { useRef, useEffect, useState, useCallback } from 'react';
import type { GameType, CustomerData, StoreSettings } from '@/lib/types';
import { MAX_OFFICIAL_TRIES, sanitizePhoneKey } from '@/lib/types';
import { supabase } from '@/lib/supabase';
import { initAudio, startBackgroundMusic, stopBackgroundMusic, playSound } from '@/lib/audio';

interface ArcadeGameProps {
  gameType: GameType;
  customerData: CustomerData;
  settings: StoreSettings;
  tenantId: string;
  tableId: string;
  onGameEnd: (won: boolean, score: number, updatedCustomer: CustomerData) => void;
  onQuit: () => void;
}

const CANVAS_SIZE = 340;
const GRID_COUNT = 17;
const GRID_SIZE = CANVAS_SIZE / GRID_COUNT;

interface Basket { x: number; y: number; width: number; height: number; speed: number; direction: number }
interface Pipe { x: number; top: number; bottom: number; passed: boolean }
interface Cloud { x: number; y: number; size: number; speed: number }

export default function ArcadeGame({ gameType, customerData, settings, tenantId, tableId, onGameEnd, onQuit }: ArcadeGameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [showRules, setShowRules] = useState(true);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  const gameIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isRunningRef = useRef(false);
  const scoreRef = useRef(0);

  // Snake
  const snakeRef = useRef<{ x: number; y: number }[]>([]);
  const foodRef = useRef({ x: 0, y: 0 });
  const dxRef = useRef(GRID_SIZE);
  const dyRef = useRef(0);

  // Flappy
  const birdRef = useRef({ x: 60, y: 150, radius: 12, velocity: 0, gravity: 0.38, jump: -6.2, wingAngle: 0 });
  const pipesRef = useRef<Pipe[]>([]);
  const pipeFrameCountRef = useRef(0);
  const cloudsRef = useRef<Cloud[]>([
    { x: 30, y: 40, size: 0.8, speed: 0.4 },
    { x: 180, y: 70, size: 1.2, speed: 0.6 },
    { x: 290, y: 35, size: 0.9, speed: 0.5 },
  ]);
  const groundOffsetRef = useRef(0);

  // Egg Toss
  const eggRef = useRef({ x: 170, y: 280, radius: 9, vy: 0, vx: 0, isFlying: false, basketIndex: 0, rotation: 0 });
  const eggBasketsRef = useRef<Basket[]>([]);
  const eggCameraYRef = useRef(0);
  const targetCameraYRef = useRef(0);

  const isPractice = customerData.tries_used < 0;

  // Keep a ref to the latest target score so active game loops pick up real-time settings changes
  const targetScoreRef = useRef(settings.target_score);
  useEffect(() => {
    targetScoreRef.current = settings.target_score;
  }, [settings.target_score]);

  const updateScore = useCallback((s: number) => {
    scoreRef.current = s;
    setScore(s);
  }, []);

  const endGame = useCallback(async (won: boolean) => {
    if (gameIntervalRef.current) clearInterval(gameIntervalRef.current);
    stopBackgroundMusic();
    isRunningRef.current = false;

    const finalScore = scoreRef.current;
    let couponCode = customerData.win_code || '';
    const updatedCustomer: CustomerData = { ...customerData };

    if (won && (!couponCode || couponCode === '-')) {
      couponCode = 'WIN-' + Math.floor(1000 + Math.random() * 9000);
      updatedCustomer.win_code = couponCode;
    }

    if (!isPractice) {
      updatedCustomer.tries_used = customerData.tries_used + 1;
      updatedCustomer.last_played_time = Date.now();
      updatedCustomer.score = finalScore;
      if (won) {
        updatedCustomer.has_won = true;
        updatedCustomer.win_code = couponCode;
        updatedCustomer.status = 'WON';
      } else {
        updatedCustomer.has_won = false;
        updatedCustomer.win_code = '';
        updatedCustomer.status = 'LOSS';
      }

      const leadKey = sanitizePhoneKey(customerData.phone);
      const { error: updateError } = await supabase
        .from('leads')
        .update({
          tries_used: updatedCustomer.tries_used,
          last_played_time: updatedCustomer.last_played_time,
          has_won: updatedCustomer.has_won,
          win_code: won ? couponCode : '',
          status: updatedCustomer.status,
          score: finalScore,
        })
        .eq('tenant_id', tenantId)
        .eq('lead_key', leadKey);

      if (updateError) {
        console.error('Failed to update lead status:', updateError);
      }

      // Update analytics (fire and forget)
      supabase
        .from('analytics')
        .select('*')
        .eq('tenant_id', tenantId)
        .maybeSingle()
        .then(({ data: currentAnalytics }) => {
          const currentPlays = currentAnalytics?.total_plays ?? 0;
          const currentWins = currentAnalytics?.total_wins ?? 0;
          supabase
            .from('analytics')
            .upsert({
              tenant_id: tenantId,
              total_plays: currentPlays + 1,
              total_wins: currentWins + (won ? 1 : 0),
            })
            .then();
        });
    }

    onGameEnd(won, finalScore, updatedCustomer);
  }, [customerData, isPractice, tenantId, onGameEnd]);

  const initEggTossGame = useCallback(() => {
    const baskets: Basket[] = [];
    baskets.push({ x: 170, y: 280, width: 58, height: 28, speed: 1.2, direction: 1 });

    for (let i = 1; i <= 35; i++) {
      const speed = i <= 3 ? 1.1 : i <= 6 ? 1.4 + (i - 3) * 0.15 : 1.8 + Math.min(2.2, (i - 6) * 0.1);
      baskets.push({
        x: Math.floor(Math.random() * 220) + 60,
        y: 280 - i * 110,
        width: Math.max(44, 58 - i * 0.3),
        height: 28,
        speed,
        direction: i % 2 === 0 ? 1 : -1,
      });
    }

    eggBasketsRef.current = baskets;
    const egg = eggRef.current;
    egg.basketIndex = 0;
    egg.x = baskets[0].x;
    egg.y = baskets[0].y + 2;
    egg.vy = 0;
    egg.vx = 0;
    egg.isFlying = false;
    egg.rotation = 0;
    eggCameraYRef.current = 0;
    targetCameraYRef.current = 0;
  }, []);

  // Snake loop
  const gameLoopSnake = useCallback(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;

    const snake = snakeRef.current;
    const head = { x: snake[0].x + dxRef.current, y: snake[0].y + dyRef.current };

    if (head.x < 0 || head.x >= CANVAS_SIZE || head.y < 0 || head.y >= CANVAS_SIZE) {
      playSound('hit');
      endGame(false);
      return;
    }

    for (let i = 0; i < snake.length; i++) {
      if (snake[i].x === head.x && snake[i].y === head.y) {
        playSound('hit');
        endGame(false);
        return;
      }
    }

    snake.unshift(head);

    if (head.x === foodRef.current.x && head.y === foodRef.current.y) {
      const newScore = scoreRef.current + 1;
      updateScore(newScore);
      playSound('score');
      if (newScore >= targetScoreRef.current) {
        playSound('win');
        endGame(true);
        return;
      }
      foodRef.current = {
        x: Math.floor(Math.random() * GRID_COUNT) * GRID_SIZE,
        y: Math.floor(Math.random() * GRID_COUNT) * GRID_SIZE,
      };
    } else {
      snake.pop();
    }

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(foodRef.current.x + GRID_SIZE / 2, foodRef.current.y + GRID_SIZE / 2, GRID_SIZE / 2 - 2, 0, Math.PI * 2);
    ctx.fill();

    snake.forEach((part, index) => {
      ctx.fillStyle = index === 0 ? '#10b981' : '#34d399';
      ctx.fillRect(part.x, part.y, GRID_SIZE - 2, GRID_SIZE - 2);
    });
  }, [endGame, updateScore]);

  // Flappy loop
  const gameLoopFlappy = useCallback(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;

    const bird = birdRef.current;
    const groundHeight = 24;
    bird.velocity += bird.gravity;
    bird.y += bird.velocity;

    if (bird.y + bird.radius >= CANVAS_SIZE - groundHeight || bird.y - bird.radius <= 0) {
      playSound('hit');
      endGame(false);
      return;
    }

    pipeFrameCountRef.current++;
    if (pipeFrameCountRef.current % 85 === 0) {
      const minHeight = 35;
      const maxHeight = CANVAS_SIZE - groundHeight - 115 - minHeight;
      const topHeight = Math.floor(Math.random() * (maxHeight - minHeight + 1)) + minHeight;
      pipesRef.current.push({
        x: CANVAS_SIZE,
        top: topHeight,
        bottom: CANVAS_SIZE - groundHeight - topHeight - 115,
        passed: false,
      });
    }

    const pipes = pipesRef.current;
    const pipeWidth = 48;
    for (let i = pipes.length - 1; i >= 0; i--) {
      pipes[i].x -= 2.2;

      if (
        bird.x + bird.radius - 2 > pipes[i].x &&
        bird.x - bird.radius + 2 < pipes[i].x + pipeWidth &&
        (bird.y - bird.radius + 2 < pipes[i].top || bird.y + bird.radius - 2 > CANVAS_SIZE - groundHeight - pipes[i].bottom)
      ) {
        playSound('hit');
        endGame(false);
        return;
      }

      if (!pipes[i].passed && pipes[i].x + pipeWidth < bird.x) {
        pipes[i].passed = true;
        const newScore = scoreRef.current + 1;
        updateScore(newScore);
        playSound('score');
        if (newScore >= targetScoreRef.current) {
          playSound('win');
          endGame(true);
          return;
        }
      }

      if (pipes[i].x + pipeWidth < 0) {
        pipes.splice(i, 1);
      }
    }

    const skyGradient = ctx.createLinearGradient(0, 0, 0, CANVAS_SIZE);
    skyGradient.addColorStop(0, '#38bdf8');
    skyGradient.addColorStop(0.7, '#bae6fd');
    skyGradient.addColorStop(1, '#e0f2fe');
    ctx.fillStyle = skyGradient;
    ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    cloudsRef.current.forEach((c) => {
      c.x -= c.speed;
      if (c.x < -50) c.x = 360;
      drawCloud(ctx, c.x, c.y, c.size);
    });

    pipes.forEach((p) => {
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(p.x, 0, pipeWidth, p.top);
      ctx.fillStyle = '#16a34a';
      ctx.fillRect(p.x - 3, p.top - 16, pipeWidth + 6, 16);
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(p.x, CANVAS_SIZE - groundHeight - p.bottom, pipeWidth, p.bottom);
      ctx.fillStyle = '#16a34a';
      ctx.fillRect(p.x - 3, CANVAS_SIZE - groundHeight - p.bottom, pipeWidth + 6, 16);
    });

    groundOffsetRef.current = (groundOffsetRef.current + 2.2) % 16;
    ctx.fillStyle = '#84cc16';
    ctx.fillRect(0, CANVAS_SIZE - groundHeight, CANVAS_SIZE, 6);
    ctx.fillStyle = '#d97706';
    ctx.fillRect(0, CANVAS_SIZE - groundHeight + 6, CANVAS_SIZE, groundHeight - 6);

    drawFlappyBird(ctx, bird);
  }, [endGame, updateScore]);

  // Egg Toss loop
  const gameLoopEggToss = useCallback(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;

    const baskets = eggBasketsRef.current;
    const egg = eggRef.current;

    for (let i = 0; i < baskets.length; i++) {
      const b = baskets[i];
      b.x += b.speed * b.direction;
      if (b.x + b.width / 2 >= CANVAS_SIZE - 15) {
        b.x = CANVAS_SIZE - 15 - b.width / 2;
        b.direction = -1;
      } else if (b.x - b.width / 2 <= 15) {
        b.x = 15 + b.width / 2;
        b.direction = 1;
      }
    }

    if (egg.isFlying) {
      egg.vy += 0.42;
      egg.y += egg.vy;
      egg.x += egg.vx;
      egg.rotation += 0.09;

      for (let nextIndex = egg.basketIndex + 1; nextIndex < baskets.length; nextIndex++) {
        const b = baskets[nextIndex];
        const dxa = Math.abs(egg.x - b.x);
        const dya = egg.y - b.y;

        if (egg.vy > 0 && dya >= -8 && dya <= 22 && dxa <= b.width / 2 + 6) {
          egg.isFlying = false;
          egg.basketIndex = nextIndex;
          egg.y = b.y + 2;
          egg.vy = 0;
          egg.vx = 0;
          egg.rotation = 0;

          updateScore(egg.basketIndex);
          playSound('catch');
          playSound('score');

          if (egg.basketIndex >= targetScoreRef.current) {
            playSound('win');
            endGame(true);
            return;
          }
          break;
        }
      }

      if (egg.y - eggCameraYRef.current > CANVAS_SIZE + 60) {
        playSound('splat');
        endGame(false);
        return;
      }
    } else {
      const currentB = baskets[egg.basketIndex];
      egg.x = currentB.x;
      egg.y = currentB.y + 2;
    }

    targetCameraYRef.current = egg.y - 220;
    eggCameraYRef.current += (targetCameraYRef.current - eggCameraYRef.current) * 0.1;

    drawEggTossBackground(ctx, eggCameraYRef.current, cloudsRef.current);

    for (let i = 0; i < baskets.length; i++) {
      const b = baskets[i];
      const renderY = b.y - eggCameraYRef.current;
      if (renderY >= -50 && renderY <= 390) {
        drawBasketBack(ctx, b, renderY);
        if (!egg.isFlying && egg.basketIndex === i) {
          drawEgg(ctx, egg, egg.x, egg.y - eggCameraYRef.current);
        }
        drawBasketFront(ctx, b, renderY);
      }
    }

    if (egg.isFlying) {
      drawEgg(ctx, egg, egg.x, egg.y - eggCameraYRef.current);
    }
  }, [endGame, updateScore]);

  const startGame = useCallback(() => {
    updateScore(0);
    isRunningRef.current = true;

    startBackgroundMusic(gameType, () => isRunningRef.current);

    if (gameIntervalRef.current) clearInterval(gameIntervalRef.current);

    if (gameType === 'snake') {
      snakeRef.current = [{ x: 8 * GRID_SIZE, y: 8 * GRID_SIZE }];
      dxRef.current = GRID_SIZE;
      dyRef.current = 0;
      foodRef.current = {
        x: Math.floor(Math.random() * GRID_COUNT) * GRID_SIZE,
        y: Math.floor(Math.random() * GRID_COUNT) * GRID_SIZE,
      };
      gameIntervalRef.current = setInterval(gameLoopSnake, 130);
    } else if (gameType === 'flappy') {
      birdRef.current = { ...birdRef.current, y: 150, velocity: 0 };
      pipesRef.current = [];
      pipeFrameCountRef.current = 0;
      gameIntervalRef.current = setInterval(gameLoopFlappy, 1000 / 60);
    } else if (gameType === 'eggtoss') {
      initEggTossGame();
      gameIntervalRef.current = setInterval(gameLoopEggToss, 1000 / 60);
    }
  }, [gameType, gameLoopSnake, gameLoopFlappy, gameLoopEggToss, initEggTossGame, updateScore]);

  const startCountdown = useCallback(() => {
    initAudio();
    setShowRules(false);
    setCountdown(3);

    let count = 3;
    const timer = setInterval(() => {
      count--;
      if (count > 0) {
        setCountdown(count);
      } else {
        clearInterval(timer);
        setCountdown(null);
        startGame();
      }
    }, 800);
  }, [startGame]);

  const flapBird = () => {
    initAudio();
    if (isRunningRef.current && gameType === 'flappy') {
      birdRef.current.velocity = birdRef.current.jump;
      playSound('jump');
    }
  };

  const tossEgg = () => {
    initAudio();
    if (!isRunningRef.current || gameType !== 'eggtoss') return;
    const egg = eggRef.current;
    if (!egg.isFlying) {
      egg.isFlying = true;
      egg.vy = -12.5;
      egg.vx = eggBasketsRef.current[egg.basketIndex].speed * eggBasketsRef.current[egg.basketIndex].direction * 0.45;
      playSound('toss');
    }
  };

  const handleCanvasClick = () => {
    if (gameType === 'flappy') flapBird();
    else if (gameType === 'eggtoss') tossEgg();
  };

  const snakeDir = (dir: 'up' | 'down' | 'left' | 'right') => {
    if (dir === 'up' && dyRef.current === 0) { dxRef.current = 0; dyRef.current = -GRID_SIZE; }
    if (dir === 'down' && dyRef.current === 0) { dxRef.current = 0; dyRef.current = GRID_SIZE; }
    if (dir === 'left' && dxRef.current === 0) { dxRef.current = -GRID_SIZE; dyRef.current = 0; }
    if (dir === 'right' && dxRef.current === 0) { dxRef.current = GRID_SIZE; dyRef.current = 0; }
  };

  // Keyboard controls
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (!isRunningRef.current) return;
      if (gameType === 'snake') {
        if (e.key === 'ArrowUp' && dyRef.current === 0) { dxRef.current = 0; dyRef.current = -GRID_SIZE; }
        if (e.key === 'ArrowDown' && dyRef.current === 0) { dxRef.current = 0; dyRef.current = GRID_SIZE; }
        if (e.key === 'ArrowLeft' && dxRef.current === 0) { dxRef.current = -GRID_SIZE; dyRef.current = 0; }
        if (e.key === 'ArrowRight' && dxRef.current === 0) { dxRef.current = GRID_SIZE; dyRef.current = 0; }
      } else if (gameType === 'flappy' && (e.key === ' ' || e.key === 'ArrowUp')) {
        flapBird();
      } else if (gameType === 'eggtoss' && (e.key === ' ' || e.key === 'ArrowUp')) {
        tossEgg();
      }
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [gameType]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (gameIntervalRef.current) clearInterval(gameIntervalRef.current);
      stopBackgroundMusic();
    };
  }, []);

  // Canvas DPR init
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = CANVAS_SIZE * dpr;
    canvas.height = CANVAS_SIZE * dpr;
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.scale(dpr, dpr);
  }, []);

  const triesBadge = isPractice
    ? 'Practice Round'
    : `Official Try ${customerData.tries_used + 1}/${MAX_OFFICIAL_TRIES}`;
  const badgeColor = isPractice ? 'bg-sky-500' : 'bg-red-400';

  return (
    <div className="flex flex-col flex-1 px-5 py-4 overflow-y-auto">
      <button
        onClick={() => endGame(false)}
        className="w-full py-2.5 mb-3 rounded-xl bg-gradient-to-br from-slate-300 to-slate-400 text-slate-700 font-bold text-[13px]"
      >
        🏳️ Quit Game
      </button>

      <div className="relative w-[340px] h-[340px] mx-auto bg-slate-50 border-[3px] border-slate-200 rounded-2xl flex items-center justify-center overflow-hidden">
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          className="block bg-white rounded-[10px] cursor-pointer"
          style={{ width: 340, height: 340, touchAction: 'none' }}
        />

        {showRules && (
          <div className="absolute inset-0 bg-white/95 backdrop-blur-sm flex flex-col justify-center items-center p-4 text-center z-10 rounded-[10px]">
            <h3 className="text-red-400 text-lg font-bold mt-0">Game Rules</h3>
            <ul className="text-left text-[11px] text-slate-500 my-2 pl-3 leading-relaxed list-disc">
              <li><strong>1 Practice Trial:</strong> Warm up round.</li>
              <li><strong>3 Official Tries:</strong> Reach target score to win reward.</li>
            </ul>
            <button
              onClick={startCountdown}
              className="w-full py-3.5 rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-bold text-[15px] shadow-lg shadow-red-400/30 hover:translate-y-[-1px] transition-transform"
            >
              Got It, Let's Play!
            </button>
          </div>
        )}

        {countdown !== null && (
          <div className="absolute inset-0 bg-white/95 flex justify-center items-center z-10 rounded-[10px]">
            <div className="text-[50px] font-black text-red-400">{countdown}</div>
          </div>
        )}
      </div>

      {gameType === 'snake' && (
        <div className="grid gap-2.5 justify-center mt-3.5" style={{ gridTemplateColumns: 'repeat(3, 65px)', gridTemplateRows: 'repeat(2, 50px)' }}>
          <button onClick={() => snakeDir('up')} className="bg-white border border-slate-200 shadow-sm rounded-xl text-xl flex items-center justify-center active:bg-red-400 active:text-white" style={{ gridColumn: 2, gridRow: 1 }}>⬆️</button>
          <button onClick={() => snakeDir('left')} className="bg-white border border-slate-200 shadow-sm rounded-xl text-xl flex items-center justify-center active:bg-red-400 active:text-white" style={{ gridColumn: 1, gridRow: 2 }}>⬅️</button>
          <button onClick={() => snakeDir('down')} className="bg-white border border-slate-200 shadow-sm rounded-xl text-xl flex items-center justify-center active:bg-red-400 active:text-white" style={{ gridColumn: 2, gridRow: 2 }}>⬇️</button>
          <button onClick={() => snakeDir('right')} className="bg-white border border-slate-200 shadow-sm rounded-xl text-xl flex items-center justify-center active:bg-red-400 active:text-white" style={{ gridColumn: 3, gridRow: 2 }}>➡️</button>
        </div>
      )}

      {gameType === 'flappy' && (
        <div className="flex justify-center mt-3.5">
          <button onClick={flapBird} className="w-[200px] h-[60px] rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-extrabold text-lg shadow-lg shadow-red-400/30">
            Jump ⬆️
          </button>
        </div>
      )}

      {gameType === 'eggtoss' && (
        <div className="flex justify-center mt-3.5">
          <button onClick={tossEgg} className="w-[200px] h-[60px] rounded-xl bg-gradient-to-br from-red-400 to-orange-400 text-white font-extrabold text-lg shadow-lg shadow-red-400/30">
            Toss Egg 🥚
          </button>
        </div>
      )}
    </div>
  );
}

// === Drawing helpers (module-level, pure functions) ===

function drawCloud(ctx: CanvasRenderingContext2D, x: number, y: number, scale: number) {
  ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
  ctx.beginPath();
  ctx.arc(x, y, 12 * scale, 0, Math.PI * 2);
  ctx.arc(x + 10 * scale, y - 8 * scale, 14 * scale, 0, Math.PI * 2);
  ctx.arc(x + 24 * scale, y - 4 * scale, 12 * scale, 0, Math.PI * 2);
  ctx.arc(x + 32 * scale, y, 10 * scale, 0, Math.PI * 2);
  ctx.fill();
}

function drawFlappyBird(ctx: CanvasRenderingContext2D, bird: { x: number; y: number; radius: number; velocity: number; wingAngle: number }) {
  ctx.save();
  ctx.translate(bird.x, bird.y);
  const angle = Math.min(Math.PI / 4, Math.max(-Math.PI / 4, bird.velocity * 0.08));
  ctx.rotate(angle);

  ctx.fillStyle = '#facc15';
  ctx.beginPath();
  ctx.arc(0, 0, bird.radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = '#ca8a04';
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(4, -4, 4.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.arc(5.5, -4, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#f97316';
  ctx.beginPath();
  ctx.moveTo(7, 0);
  ctx.lineTo(15, 3);
  ctx.lineTo(7, 6);
  ctx.closePath();
  ctx.fill();

  bird.wingAngle += 0.2;
  const wingY = Math.sin(bird.wingAngle) * 3;
  ctx.fillStyle = '#eab308';
  ctx.beginPath();
  ctx.ellipse(-4, wingY, 6, 4, Math.PI / 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function drawEggTossBackground(ctx: CanvasRenderingContext2D, cameraY: number, clouds: Cloud[]) {
  const skyGradient = ctx.createLinearGradient(0, 0, 0, CANVAS_SIZE);
  skyGradient.addColorStop(0, '#38bdf8');
  skyGradient.addColorStop(0.5, '#7dd3fc');
  skyGradient.addColorStop(1, '#bae6fd');
  ctx.fillStyle = skyGradient;
  ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

  clouds.forEach((c) => {
    c.x -= c.speed * 0.4;
    if (c.x < -60) c.x = 370;
    drawCloud(ctx, c.x, c.y + (cameraY * 0.05) % 150, c.size);
  });

  const hillY = CANVAS_SIZE - 30 - (cameraY * 0.12) % 400;
  ctx.fillStyle = '#4ade80';
  ctx.beginPath();
  ctx.arc(80, hillY + 80, 160, Math.PI, 0);
  ctx.arc(280, hillY + 100, 190, Math.PI, 0);
  ctx.fill();
}

function drawBasketBack(ctx: CanvasRenderingContext2D, b: Basket, renderY: number) {
  ctx.save();
  ctx.translate(b.x, renderY);
  ctx.fillStyle = 'rgba(0,0,0,0.18)';
  ctx.beginPath();
  ctx.ellipse(0, 9, b.width / 2 + 2, b.height / 3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#78350f';
  ctx.beginPath();
  ctx.ellipse(0, 0, b.width / 2 - 3, b.height / 2.8, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.ellipse(0, 3, b.width / 2, b.height / 2.2, 0, 0, Math.PI);
  ctx.fill();
  ctx.restore();
}

function drawBasketFront(ctx: CanvasRenderingContext2D, b: Basket, renderY: number) {
  ctx.save();
  ctx.translate(b.x, renderY);
  ctx.fillStyle = '#d97706';
  ctx.beginPath();
  ctx.ellipse(0, 4, b.width / 2, b.height / 2, 0, 0, Math.PI);
  ctx.fill();
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = '#92400e';
  ctx.beginPath();
  ctx.ellipse(0, 0, b.width / 2, b.height / 3.2, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = '#fef3c7';
  ctx.beginPath();
  ctx.ellipse(0, -1, b.width / 2 - 2, b.height / 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawEgg(ctx: CanvasRenderingContext2D, egg: { radius: number; isFlying: boolean; rotation: number }, x: number, renderY: number) {
  ctx.save();
  ctx.translate(x, renderY);
  ctx.rotate(egg.rotation);

  if (egg.isFlying) {
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.beginPath();
    ctx.ellipse(0, 14, egg.radius, egg.radius / 2.2, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.fillStyle = '#fff7ed';
  ctx.beginPath();
  ctx.ellipse(0, 0, egg.radius, egg.radius * 1.28, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = '#fed7aa';
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.ellipse(-3, -3, 2.5, 4.5, -Math.PI / 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
