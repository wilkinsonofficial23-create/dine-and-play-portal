export type GameType = 'snake' | 'flappy' | 'eggtoss';

export type ScreenName =
  | 'hub'
  | 'gameSelect'
  | 'registration'
  | 'game'
  | 'result'
  | 'ownerLogin'
  | 'ownerDashboard';

export interface StoreSettings {
  tenant_id: string;
  business_name: string;
  sub_text: string;
  logo_url: string;
  whatsapp_number: string;
  target_score: number;
  offer_desc: string;
  store_password: string;
}

export type LeadStatus = 'PENDING' | 'WON' | 'LOSS';

export interface Lead {
  id: string;
  tenant_id: string;
  lead_key: string;
  name: string;
  phone: string;
  email: string;
  promo_consent: string;
  table_id: string;
  tries_used: number;
  last_played_time: number;
  has_won: boolean;
  win_code: string;
  status: LeadStatus;
  score: number;
  created_at: string;
}

export interface Analytics {
  tenant_id: string;
  total_plays: number;
  total_wins: number;
}

export interface CustomerData {
  name: string;
  phone: string;
  email: string;
  promo_consent: string;
  tries_used: number;
  last_played_time: number;
  has_won: boolean;
  win_code: string;
  status: LeadStatus;
  score: number;
}

export const MAX_OFFICIAL_TRIES = 3;
export const COOLDOWN_HOURS = 24;

export const COUNTRY_CODES = [
  { name: 'United Arab Emirates', code: '+971', flag: '🇦🇪' },
  { name: 'United States', code: '+1', flag: '🇺🇸' },
  { name: 'United Kingdom', code: '+44', flag: '🇬🇧' },
  { name: 'India', code: '+91', flag: '🇮🇳' },
  { name: 'Saudi Arabia', code: '+966', flag: '🇸🇦' },
  { name: 'Qatar', code: '+974', flag: '🇶🇦' },
];

export const DEFAULT_STORE_SETTINGS: StoreSettings = {
  tenant_id: 'default_store',
  business_name: 'Xpress Cafe & Lounge',
  sub_text: 'Scan table QR, play game & win discounts!',
  logo_url: '',
  whatsapp_number: '971501234567',
  target_score: 5,
  offer_desc: '15% off your total bill or a complimentary dessert!',
  store_password: 'store123',
};

export function sanitizePhoneKey(phone: string): string {
  return phone.replace(/[^0-9]/g, '');
}

export function validatePhone(phone: string): string | null {
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 7) return 'Phone number must be at least 7 digits';
  if (digits.length > 15) return 'Phone number must be at most 15 digits';
  return null;
}

export function validateEmail(email: string): string | null {
  const trimmed = email.trim();
  if (!trimmed) return 'Email is required';
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  if (!re.test(trimmed)) return 'Enter a valid email address (e.g. name@example.com)';
  return null;
}
